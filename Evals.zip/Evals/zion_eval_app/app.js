const state = {
  summary: null,
  tasks: [],
  originalSegments: [],
  finalSegments: [],
  issues: [],
  overlaps: [],
  selectedTaskId: null,
  selectedSegmentId: null,
  filters: {
    search: "",
    issueType: "all",
    severity: "all",
    trainer: "all",
    sort: "risk",
    overlapOnly: false,
    criticalOnly: false,
    issuesOnlyTimeline: false,
    zoom: 1,
  },
};

const els = {};

const EVAL_INFO = [
  {
    name: "segment_overlap_eval",
    severity: "critical/high",
    checks: "Final timeline segments that overlap each other in time.",
    why: "Two final captions should not normally claim the same time window unless the schema explicitly supports parallel actions.",
    limitation: "Flags internal timeline conflict only; it does not know which segment is visually correct.",
  },
  {
    name: "timestamp_gap_eval",
    severity: "high/medium",
    checks: "Large gaps between consecutive final segments.",
    why: "A gap may indicate a missing phase or a missing `No relevant actions` segment.",
    limitation: "Some gaps can be valid if nothing relevant happens.",
  },
  {
    name: "timestamp_consistency_eval",
    severity: "critical",
    checks: "`start >= end`, timestamps outside video duration, or impossible segment ranges.",
    why: "Invalid ranges break timeline playback and downstream training data alignment.",
    limitation: "Does not verify whether the timestamp tightly bounds the real action.",
  },
  {
    name: "timestamp_format_eval",
    severity: "medium",
    checks: "Non-standard timestamp formatting, whitespace, tabs, numeric-only values, or parse issues.",
    why: "Mixed timestamp formats make the export harder to parse reliably.",
    limitation: "Some values may still be parseable even if style is inconsistent.",
  },
  {
    name: "schema_integrity_eval",
    severity: "critical",
    checks: "Missing captions, unparseable timestamps, missing expected fields, or schema drift.",
    why: "Each final phase needs enough structure to be reviewed and used safely.",
    limitation: "Only validates expected fields, not semantic correctness.",
  },
  {
    name: "phase_sequence_eval",
    severity: "high/medium",
    checks: "`phase_index` order, missing/duplicate/malformed `covered_markers`, and marker ordering.",
    why: "Phase order and traceability should match the final timeline sequence.",
    limitation: "Marker logic depends on how upstream segments were generated.",
  },
  {
    name: "object_reference_eval",
    severity: "high/medium",
    checks: "Captions that do not exactly reference inventory objects, or consistency notes pointing to missing inventory names.",
    why: "Zion asks for consistent standalone object descriptions across the annotation.",
    limitation: "This can produce false positives when captions use valid synonyms or shortened object names.",
  },
  {
    name: "zion_language_policy_eval",
    severity: "high/medium",
    checks: "Body/head/viewpoint movement terms and internal-state language like `walk`, `legs`, `head`, `tries to`, or `seems to`.",
    why: "Instructions say Zion should focus on observable left/right/both-hand actions.",
    limitation: "Keyword-based detection can flag phrases that are acceptable in context.",
  },
  {
    name: "no_action_segment_eval",
    severity: "high",
    checks: "`No relevant actions` captions that also contain action verbs.",
    why: "A no-action segment should not simultaneously describe a relevant action.",
    limitation: "Only triggers when both patterns appear in the same caption.",
  },
  {
    name: "segment_granularity_eval",
    severity: "high/low",
    checks: "Very long or very short final segments.",
    why: "Long segments often hide merged actions; tiny segments can indicate over-splitting or timestamp noise.",
    limitation: "Duration alone cannot prove a segment should be split or merged.",
  },
  {
    name: "coverage_eval",
    severity: "medium",
    checks: "First segment starts late or final segment ends well before video duration.",
    why: "The annotation may be missing beginning/end coverage or no-action labeling.",
    limitation: "Valid if the uncovered area truly has no relevant action and the schema allows omission.",
  },
  {
    name: "caption_visual_evidence_eval",
    severity: "low",
    checks: "`caption` and `visual_evidence` diverge when both fields exist.",
    why: "If both fields are expected to align, drift can indicate inconsistent final data.",
    limitation: "In this export, `visual_evidence` may be redundant or intentionally different.",
  },
];

function $(id) {
  return document.getElementById(id);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function fmt(value, digits = 0) {
  if (value === null || value === undefined || value === "") return "0";
  return Number(value).toLocaleString(undefined, { maximumFractionDigits: digits });
}

function fmtTime(seconds) {
  if (seconds === null || seconds === undefined || Number.isNaN(Number(seconds))) return "";
  const n = Number(seconds);
  const minutes = Math.floor(n / 60);
  const rem = n - minutes * 60;
  return `${String(minutes).padStart(2, "0")}:${rem.toFixed(3).padStart(6, "0")}`;
}

function severityClass(severity) {
  return ["critical", "high", "medium", "low"].includes(severity) ? severity : "";
}

function severityRank(severity) {
  return { critical: 4, high: 3, medium: 2, low: 1 }[severity] || 0;
}

async function loadJson(path) {
  const response = await fetch(path);
  if (!response.ok) throw new Error(`Failed to load ${path}`);
  return response.json();
}

async function init() {
  [
    els.searchInput,
    els.issueTypeSelect,
    els.severitySelect,
    els.trainerSelect,
    els.sortSelect,
    els.overlapOnly,
    els.criticalOnly,
    els.zoomRange,
    els.issuesOnlyTimeline,
    els.resetFiltersBtn,
    els.exportFilteredBtn,
  ] = [
    $("searchInput"),
    $("issueTypeSelect"),
    $("severitySelect"),
    $("trainerSelect"),
    $("sortSelect"),
    $("overlapOnly"),
    $("criticalOnly"),
    $("zoomRange"),
    $("issuesOnlyTimeline"),
    $("resetFiltersBtn"),
    $("exportFilteredBtn"),
  ];

  const [summary, tasks, originalSegments, finalSegments, issues, overlaps] = await Promise.all([
    loadJson("./data/summary.json"),
    loadJson("./data/tasks.json"),
    loadJson("./data/segments_original.json"),
    loadJson("./data/segments_final.json"),
    loadJson("./data/issues.json"),
    loadJson("./data/overlaps.json"),
  ]);

  Object.assign(state, { summary, tasks, originalSegments, finalSegments, issues, overlaps });
  state.selectedTaskId = [...tasks].sort((a, b) => b.risk_score - a.risk_score)[0]?.task_id || null;

  hydrateFilters();
  bindEvents();
  renderAll();
}

function hydrateFilters() {
  const issueTypes = [...new Set(state.issues.map((issue) => issue.eval_name))].sort();
  els.issueTypeSelect.insertAdjacentHTML(
    "beforeend",
    issueTypes.map((type) => `<option value="${escapeHtml(type)}">${escapeHtml(type)}</option>`).join("")
  );

  const trainers = [...new Set(state.tasks.map((task) => task.trainer_user_id).filter(Boolean))].sort();
  els.trainerSelect.insertAdjacentHTML(
    "beforeend",
    trainers.map((trainer) => `<option value="${escapeHtml(trainer)}">${escapeHtml(trainer)}</option>`).join("")
  );
}

function bindEvents() {
  els.searchInput.addEventListener("input", () => {
    state.filters.search = els.searchInput.value.trim().toLowerCase();
    renderAll();
  });
  els.issueTypeSelect.addEventListener("change", () => {
    state.filters.issueType = els.issueTypeSelect.value;
    renderAll();
  });
  els.severitySelect.addEventListener("change", () => {
    state.filters.severity = els.severitySelect.value;
    renderAll();
  });
  els.trainerSelect.addEventListener("change", () => {
    state.filters.trainer = els.trainerSelect.value;
    renderAll();
  });
  els.sortSelect.addEventListener("change", () => {
    state.filters.sort = els.sortSelect.value;
    renderAll();
  });
  els.overlapOnly.addEventListener("change", () => {
    state.filters.overlapOnly = els.overlapOnly.checked;
    renderAll();
  });
  els.criticalOnly.addEventListener("change", () => {
    state.filters.criticalOnly = els.criticalOnly.checked;
    renderAll();
  });
  els.zoomRange.addEventListener("input", () => {
    state.filters.zoom = Number(els.zoomRange.value);
    renderTimeline();
  });
  els.issuesOnlyTimeline.addEventListener("change", () => {
    state.filters.issuesOnlyTimeline = els.issuesOnlyTimeline.checked;
    renderTimeline();
  });
  els.resetFiltersBtn.addEventListener("click", resetFilters);
  els.exportFilteredBtn.addEventListener("click", exportFilteredCsv);
}

function resetFilters() {
  Object.assign(state.filters, {
    search: "",
    issueType: "all",
    severity: "all",
    trainer: "all",
    sort: "risk",
    overlapOnly: false,
    criticalOnly: false,
    issuesOnlyTimeline: false,
    zoom: 1,
  });
  els.searchInput.value = "";
  els.issueTypeSelect.value = "all";
  els.severitySelect.value = "all";
  els.trainerSelect.value = "all";
  els.sortSelect.value = "risk";
  els.overlapOnly.checked = false;
  els.criticalOnly.checked = false;
  els.issuesOnlyTimeline.checked = false;
  els.zoomRange.value = "1";
  renderAll();
}

function issuesForTask(taskId) {
  return state.issues.filter((issue) => issue.task_id === taskId);
}

function overlapsForTask(taskId) {
  return state.overlaps.filter((overlap) => overlap.task_id === taskId);
}

function filteredTasks() {
  const filtered = state.tasks.filter((task) => {
    const taskIssues = issuesForTask(task.task_id);
    const haystack = `${task.task_id} ${task.task_name} ${task.client_folder_name} ${task.trainer_user_id}`.toLowerCase();
    if (state.filters.search && !haystack.includes(state.filters.search)) return false;
    if (state.filters.trainer !== "all" && task.trainer_user_id !== state.filters.trainer) return false;
    if (state.filters.overlapOnly && !task.overlap_count) return false;
    if (state.filters.criticalOnly && !task.critical_count) return false;
    if (state.filters.issueType !== "all" && !taskIssues.some((issue) => issue.eval_name === state.filters.issueType)) return false;
    if (state.filters.severity !== "all" && !taskIssues.some((issue) => issue.severity === state.filters.severity)) return false;
    return true;
  });

  const sorters = {
    risk: (a, b) => b.risk_score - a.risk_score,
    overlaps: (a, b) => b.overlap_count - a.overlap_count || b.risk_score - a.risk_score,
    issues: (a, b) => b.issue_count - a.issue_count,
    duration: (a, b) => b.final_duration_secs - a.final_duration_secs,
    updated: (a, b) => String(b.date_updated).localeCompare(String(a.date_updated)),
  };
  return filtered.sort(sorters[state.filters.sort] || sorters.risk);
}

function renderAll() {
  const tasks = filteredTasks();
  if (!tasks.some((task) => task.task_id === state.selectedTaskId)) {
    state.selectedTaskId = tasks[0]?.task_id || state.tasks[0]?.task_id || null;
  }
  renderStats(tasks);
  renderEvalInfo();
  renderTaskList(tasks);
  renderSelectedTask();
}

function renderEvalInfo() {
  $("evalInfoGrid").innerHTML = EVAL_INFO.map((info) => {
    const count = state.summary.eval_counts?.[info.name] || 0;
    return `
      <article class="eval-info-card">
        <div class="eval-info-title">
          <span>${escapeHtml(info.name)}</span>
          <span class="badge">${fmt(count)}</span>
        </div>
        <div class="eval-info-meta">Typical severity: ${escapeHtml(info.severity)}</div>
        <p><strong>Checks:</strong> ${escapeHtml(info.checks)}</p>
        <p><strong>Why it matters:</strong> ${escapeHtml(info.why)}</p>
        <p class="eval-limitation"><strong>Limit:</strong> ${escapeHtml(info.limitation)}</p>
      </article>`;
  }).join("");
}

function renderStats(tasks) {
  const issueIds = new Set();
  const overlapTaskCount = tasks.filter((task) => task.overlap_count > 0).length;
  let critical = 0;
  let high = 0;
  for (const task of tasks) {
    for (const issue of issuesForTask(task.task_id)) {
      issueIds.add(issue.issue_id);
      if (issue.severity === "critical") critical += 1;
      if (issue.severity === "high") high += 1;
    }
  }
  $("statsGrid").innerHTML = [
    ["Tasks", fmt(tasks.length), "Filtered tasks"],
    ["Issues", fmt(issueIds.size), "Detected final issues"],
    ["Overlap Tasks", fmt(overlapTaskCount), "Tasks with final overlap"],
    ["Critical", fmt(critical), "Critical issue rows"],
    ["High", fmt(high), "High issue rows"],
    ["All Segments", fmt(state.summary.final_segment_count), "Final phase captions"],
  ]
    .map(
      ([label, value, sub]) => `
      <div class="stat">
        <div class="stat-value">${value}</div>
        <div class="stat-label">${label}</div>
        <div class="stat-label">${sub}</div>
      </div>`
    )
    .join("");
}

function renderTaskList(tasks) {
  $("taskCount").textContent = fmt(tasks.length);
  $("taskList").innerHTML = tasks
    .slice(0, 250)
    .map((task) => {
      const active = task.task_id === state.selectedTaskId ? "active" : "";
      const maxSeverity = task.critical_count ? "critical" : task.high_count ? "high" : task.medium_count ? "medium" : task.low_count ? "low" : "";
      return `
        <article class="task-card ${active}" data-task-id="${escapeHtml(task.task_id)}">
          <div class="task-card-title">
            <span>${escapeHtml(task.task_name || "Untitled task")}</span>
            <span>${fmt(task.risk_score)}</span>
          </div>
          <div class="task-meta">${escapeHtml(task.task_id)} · trainer ${escapeHtml(task.trainer_user_id)} · ${fmt(task.final_duration_secs, 1)}s</div>
          <div class="badge-row">
            <span class="badge ${maxSeverity}">${fmt(task.issue_count)} issues</span>
            <span class="badge critical">${fmt(task.critical_count)} critical</span>
            <span class="badge high">${fmt(task.overlap_count)} overlaps</span>
          </div>
        </article>`;
    })
    .join("");

  document.querySelectorAll(".task-card").forEach((card) => {
    card.addEventListener("click", () => {
      state.selectedTaskId = card.dataset.taskId;
      state.selectedSegmentId = null;
      renderAll();
    });
  });
}

function selectedTask() {
  return state.tasks.find((task) => task.task_id === state.selectedTaskId);
}

function renderSelectedTask() {
  const task = selectedTask();
  if (!task) return;
  $("selectedTitle").textContent = task.task_name || "Untitled task";
  $("selectedSubtitle").textContent = `${task.task_id} · ${task.final_segment_count} final segments · ${task.issue_count} issues`;
  $("riskBadge").className = `badge ${task.critical_count ? "critical" : task.high_count ? "high" : "medium"}`;
  $("riskBadge").textContent = `Risk ${task.risk_score}`;
  renderTaskDetail(task);
  renderTimeline();
  renderIssues();
}

function renderTaskDetail(task) {
  const objects = (task.object_inventory || []).slice(0, 18);
  $("taskDetail").innerHTML = `
    <div class="kv"><span>Status</span><strong>${escapeHtml(task.status)}</strong></div>
    <div class="kv"><span>Trainer</span><strong>${escapeHtml(task.trainer_user_id)}</strong></div>
    <div class="kv"><span>Duration</span><strong>${fmt(task.final_duration_secs, 3)}s</strong></div>
    <div class="kv"><span>Segments</span><strong>${fmt(task.original_segment_count)} original / ${fmt(task.final_segment_count)} final</strong></div>
    <div class="kv"><span>Overlaps</span><strong>${fmt(task.overlap_count)}</strong></div>
    <div class="kv"><span>Review</span><strong>${escapeHtml(task.review_score || "not reviewed")}</strong></div>
    <div>
      <div class="section-header"><h2>Objects</h2><span>${fmt((task.object_inventory || []).length)}</span></div>
      <div class="object-list">${objects.map((obj) => `<span class="badge">${escapeHtml(obj.canonical_name)}</span>`).join("")}</div>
    </div>
    <div>
      <div class="section-header"><h2>Eval Types</h2><span>${fmt((task.eval_names || []).length)}</span></div>
      <div class="object-list">${(task.eval_names || []).map((name) => `<span class="badge">${escapeHtml(name)}</span>`).join("") || '<span class="empty">No issues</span>'}</div>
    </div>`;
}

function segmentIssuesMap(taskId) {
  const map = new Map();
  for (const issue of issuesForTask(taskId)) {
    if (!issue.segment_id) continue;
    if (!map.has(issue.segment_id)) map.set(issue.segment_id, []);
    map.get(issue.segment_id).push(issue);
  }
  return map;
}

function renderTimeline() {
  const task = selectedTask();
  if (!task) return;
  const original = state.originalSegments.filter((segment) => segment.task_id === task.task_id);
  const final = state.finalSegments.filter((segment) => segment.task_id === task.task_id);
  const segmentIssues = segmentIssuesMap(task.task_id);
  const duration = Math.max(task.final_duration_secs || task.actual_video_duration || 1, 1);
  const width = Math.max(780, duration * 12 * state.filters.zoom);

  const renderLane = (label, source, segments) => {
    const visible = state.filters.issuesOnlyTimeline && source === "final"
      ? segments.filter((segment) => segmentIssues.has(segment.segment_id))
      : segments;
    return `
      <div class="lane" style="width:${width}px">
        <div class="lane-header"><span>${label}</span><span>${visible.length} segments</span></div>
        <div class="track">
          ${source === "final" ? renderOverlapBands(task.task_id, duration) : ""}
          ${source === "final" ? renderGapBands(task.task_id, duration) : ""}
          ${visible.map((segment) => renderSegment(segment, duration, segmentIssues)).join("")}
        </div>
      </div>`;
  };

  $("timeline").innerHTML = `
    ${renderAxis(duration, width)}
    ${renderLane("Original annotation", "original", original)}
    ${renderLane("Final annotation", "final", final)}
  `;

  document.querySelectorAll(".segment").forEach((segmentEl) => {
    segmentEl.addEventListener("click", () => {
      state.selectedSegmentId = segmentEl.dataset.segmentId;
      renderTimeline();
      renderIssues();
    });
  });
}

function renderAxis(duration, width) {
  const ticks = [];
  const step = duration > 120 ? 30 : duration > 60 ? 15 : 10;
  for (let t = 0; t <= duration + 0.01; t += step) {
    ticks.push(`<span class="tick" style="left:${(t / duration) * width}px">${fmtTime(t)}</span>`);
  }
  return `<div class="time-axis" style="width:${width}px">${ticks.join("")}</div>`;
}

function renderOverlapBands(taskId, duration) {
  return overlapsForTask(taskId)
    .map((overlap) => {
      const left = (overlap.overlap_start_sec / duration) * 100;
      const width = Math.max(0.25, (overlap.overlap_seconds / duration) * 100);
      return `<div class="overlap-band" title="${escapeHtml(overlap.overlap_seconds)}s overlap" style="left:${left}%;width:${width}%"></div>`;
    })
    .join("");
}

function renderGapBands(taskId, duration) {
  return issuesForTask(taskId)
    .filter((issue) => issue.eval_name === "timestamp_gap_eval" && issue.start_sec !== null && issue.end_sec !== null)
    .map((issue) => {
      const gapSeconds = Math.max(0, issue.end_sec - issue.start_sec);
      const left = (issue.start_sec / duration) * 100;
      const width = Math.max(0.25, (gapSeconds / duration) * 100);
      const title = `${gapSeconds.toFixed(3)}s gap (${fmtTime(issue.start_sec)} - ${fmtTime(issue.end_sec)})`;
      return `<div class="gap-band" title="${escapeHtml(title)}" style="left:${left}%;width:${width}%"></div>`;
    })
    .join("");
}

function renderSegment(segment, duration, segmentIssues) {
  if (segment.start_sec === null || segment.end_sec === null) return "";
  const left = Math.max(0, (segment.start_sec / duration) * 100);
  const width = Math.max(0.4, ((segment.end_sec - segment.start_sec) / duration) * 100);
  const issues = segmentIssues.get(segment.segment_id) || [];
  const highest = issues.sort((a, b) => severityRank(b.severity) - severityRank(a.severity))[0]?.severity || "";
  const classes = [
    "segment",
    segment.source,
    issues.length ? "has-issue" : "",
    state.selectedSegmentId === segment.segment_id ? "selected" : "",
  ].join(" ");
  const title = `${fmtTime(segment.start_sec)} - ${fmtTime(segment.end_sec)}\\n${segment.caption}`;
  return `
    <div class="${classes}" data-segment-id="${escapeHtml(segment.segment_id)}" title="${escapeHtml(title)}" style="left:${left}%;width:${width}%">
      ${highest ? `<span class="badge ${highest}">${highest}</span> ` : ""}${escapeHtml(segment.caption)}
    </div>`;
}

function renderIssues() {
  const task = selectedTask();
  if (!task) return;
  const issues = issuesForTask(task.task_id)
    .filter((issue) => !state.selectedSegmentId || issue.segment_id === state.selectedSegmentId)
    .sort((a, b) => severityRank(b.severity) - severityRank(a.severity));
  const overlaps = overlapsForTask(task.task_id).sort((a, b) => b.overlap_seconds - a.overlap_seconds);
  $("issueCountForTask").textContent = fmt(issues.length);
  $("overlapCountForTask").textContent = fmt(overlaps.length);

  $("issuesList").innerHTML = issues.length
    ? issues.map(renderIssueCard).join("")
    : `<div class="empty">No issues for this ${state.selectedSegmentId ? "segment" : "task"}.</div>`;

  $("overlapList").innerHTML = overlaps.length
    ? overlaps.map(renderOverlapCard).join("")
    : '<div class="empty">No overlap pairs detected.</div>';

  document.querySelectorAll("[data-jump-segment]").forEach((el) => {
    el.addEventListener("click", () => {
      state.selectedSegmentId = el.dataset.jumpSegment;
      renderTimeline();
      renderIssues();
    });
  });
}

function renderIssueCard(issue) {
  return `
    <article class="issue-card" ${issue.segment_id ? `data-jump-segment="${escapeHtml(issue.segment_id)}"` : ""}>
      <div class="issue-title">
        <span>${escapeHtml(issue.eval_name)}</span>
        <span class="badge ${severityClass(issue.severity)}">${escapeHtml(issue.severity)}</span>
      </div>
      <div class="issue-message">${escapeHtml(issue.message)}</div>
      ${issue.evidence ? `<div class="issue-evidence">${escapeHtml(issue.evidence)}</div>` : ""}
      <div class="issue-evidence">${fmtTime(issue.start_sec)} ${issue.end_sec ? `- ${fmtTime(issue.end_sec)}` : ""}</div>
    </article>`;
}

function renderOverlapCard(overlap) {
  return `
    <article class="issue-card" data-jump-segment="${escapeHtml(overlap.segment_b_id)}">
      <div class="issue-title">
        <span>Segments ${overlap.segment_a_index} + ${overlap.segment_b_index}</span>
        <span class="badge ${severityClass(overlap.severity)}">${escapeHtml(overlap.severity)}</span>
      </div>
      <div class="issue-message">${fmt(overlap.overlap_seconds, 3)}s overlap from ${fmtTime(overlap.overlap_start_sec)} to ${fmtTime(overlap.overlap_end_sec)}</div>
      <div class="issue-evidence">${escapeHtml(overlap.segment_a_caption.slice(0, 180))}</div>
      <div class="issue-evidence">${escapeHtml(overlap.segment_b_caption.slice(0, 180))}</div>
    </article>`;
}

function exportFilteredCsv() {
  const tasks = filteredTasks();
  const header = ["task_id", "task_name", "trainer_user_id", "risk_score", "issue_count", "critical_count", "high_count", "overlap_count"];
  const lines = [header.join(",")];
  for (const task of tasks) {
    lines.push(
      header
        .map((field) => `"${String(task[field] ?? "").replaceAll('"', '""')}"`)
        .join(",")
    );
  }
  const blob = new Blob([lines.join("\\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "zion_filtered_tasks.csv";
  link.click();
  URL.revokeObjectURL(url);
}

init().catch((error) => {
  document.body.innerHTML = `<pre style="color:#fff;padding:24px">${escapeHtml(error.stack || error.message)}</pre>`;
});
